const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { MessageCircle, Users, User, Home, ShieldCheck, Crown } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';

import NotificationCenter from '@/components/notifications/NotificationCenter';

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  
  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => db.auth.me(),
    retry: false,
  });

  useEffect(() => {
    if (user && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }, [user]);

  const navigation = [
    { name: 'Accueil', path: createPageUrl('Home'), icon: Home, pageName: 'Home' },
    { name: 'Messages', path: createPageUrl('Messaging'), icon: MessageCircle, pageName: 'Messaging' },
    { name: 'Communautés', path: createPageUrl('Communities'), icon: Users, pageName: 'Communities' },
    { name: 'Profil', path: createPageUrl('Profile'), icon: User, pageName: 'Profile' },
  ];

  // Don't show layout on home page if not logged in
  if (currentPageName === 'Home' && !user) {
    return <>{children}</>;
  }

  return (
    <div className="flex flex-col h-screen bg-background text-foreground">
      {/* Top Navigation */}
      <nav className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to={createPageUrl('Home')} className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-600 to-purple-600 flex items-center justify-center shadow-lg">
                <MessageCircle className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">
                Messify
              </span>
            </Link>

            {user && (
              <div className="flex items-center gap-2">
                <div className="hidden md:flex items-center gap-1">
                  {navigation.map((item) => {
                    const isActive = currentPageName === item.pageName;
                    return (
                      <Link
                        key={item.name}
                        to={item.path}
                        className={`flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-colors ${
                          isActive
                            ? 'bg-violet-50 text-violet-700'
                            : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                        }`}
                      >
                        <item.icon className="w-5 h-5" />
                        <span>{item.name}</span>
                      </Link>
                    );
                  })}
                </div>
                {!user?.is_subscribed && (
                  <Link
                    to="/Subscribe"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-medium bg-gradient-to-r from-violet-600 to-purple-600 text-white hover:from-violet-700 hover:to-purple-700 transition-all shadow-md shadow-violet-300"
                  >
                    <Crown className="w-4 h-4" />
                    <span className="hidden sm:inline">S'abonner</span>
                  </Link>
                )}
                {user?.is_subscribed && (
                  <Link
                    to="/Subscribe"
                    title="Abonnement actif"
                    className="flex items-center gap-1 px-2 py-1.5 rounded-xl text-sm font-medium text-violet-600 hover:bg-violet-50"
                  >
                    <Crown className="w-4 h-4 text-violet-500" />
                  </Link>
                )}
                {user?.role === 'admin' && (
                  <Link
                    to="/Admin"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-100 border border-gray-200"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span className="hidden sm:inline">Admin</span>
                  </Link>
                )}
                <NotificationCenter userEmail={user?.email} />
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {children}
      </main>

      {/* Bottom Navigation (Mobile) */}
      {user && (
        <nav className="md:hidden bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 sticky bottom-0">
          <div className="flex justify-around items-center h-16">
            {navigation.map((item) => {
              const isActive = currentPageName === item.pageName;
              return (
                <Link
                  key={item.name}
                  to={item.path}
                  className={`flex flex-col items-center gap-1 px-3 py-2 ${
                    isActive ? 'text-violet-600' : 'text-gray-600'
                  }`}
                >
                  <item.icon className={`w-6 h-6 ${isActive ? 'stroke-2' : ''}`} />
                  <span className="text-xs font-medium">{item.name}</span>
                </Link>
              );
            })}
          </div>
        </nav>
      )}
    </div>
  );
}