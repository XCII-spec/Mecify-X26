const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Key, CheckCircle, Loader2, Crown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

export default function Subscribe() {
  const [code, setCode] = useState('');
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => db.auth.me(),
  });

  const activateMutation = useMutation({
    mutationFn: async (inputCode) => {
      const trimmed = inputCode.trim().toUpperCase();
      
      // Find matching code
      const codes = await db.entities.SubscriptionCode.filter({ code: trimmed, is_used: false });
      
      if (!codes || codes.length === 0) {
        throw new Error('Code invalide ou déjà utilisé.');
      }

      const codeRecord = codes[0];

      // Calculate expiry
      let expiresAt = null;
      if (codeRecord.duration_days > 0) {
        const d = new Date();
        d.setDate(d.getDate() + codeRecord.duration_days);
        expiresAt = d.toISOString();
      }

      // Mark code as used
      await db.entities.SubscriptionCode.update(codeRecord.id, {
        ...codeRecord,
        is_used: true,
        used_by_email: user.email,
        used_at: new Date().toISOString(),
      });

      // Update user subscription
      await db.auth.updateMe({
        is_subscribed: true,
        subscription_code: trimmed,
        ...(expiresAt && { subscription_expires_at: expiresAt }),
      });

      return codeRecord;
    },
    onSuccess: (codeRecord) => {
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
      toast.success('Abonnement activé avec succès !');
    },
    onError: (err) => {
      toast.error(err.message || 'Erreur lors de l\'activation');
    },
  });

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-violet-500" />
      </div>
    );
  }

  if (user.is_subscribed) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-50 to-purple-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-xl border border-violet-100 p-10 max-w-md w-full text-center">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-violet-500 to-purple-500 flex items-center justify-center mx-auto mb-6">
            <Crown className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Abonnement actif !</h1>
          <p className="text-gray-500 mb-4">Vous bénéficiez déjà d'un abonnement premium.</p>
          {user.subscription_expires_at && (
            <p className="text-sm text-violet-600 font-medium">
              Expire le {new Date(user.subscription_expires_at).toLocaleDateString('fr-FR')}
            </p>
          )}
          {!user.subscription_expires_at && (
            <p className="text-sm text-green-600 font-medium">Abonnement illimité</p>
          )}
          <Button
            className="mt-6 bg-gradient-to-r from-violet-600 to-purple-600"
            onClick={() => window.history.back()}
          >
            Retour
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 to-purple-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-xl border border-violet-100 p-10 max-w-md w-full">
        <div className="text-center mb-8">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-violet-500 to-purple-500 flex items-center justify-center mx-auto mb-4">
            <Crown className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Activer un abonnement</h1>
          <p className="text-gray-500 mt-2">Entrez votre code d'activation pour débloquer l'accès premium.</p>
        </div>

        <div className="space-y-4">
          <Input
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            placeholder="XXXX-XXXX-XXXX"
            className="text-center font-mono text-lg tracking-widest border-2 border-violet-200 focus:border-violet-500 h-14"
            onKeyDown={(e) => e.key === 'Enter' && code.trim() && activateMutation.mutate(code)}
          />
          <Button
            onClick={() => activateMutation.mutate(code)}
            disabled={!code.trim() || activateMutation.isPending}
            className="w-full h-12 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700 text-base font-semibold"
          >
            {activateMutation.isPending ? (
              <Loader2 className="w-5 h-5 animate-spin mr-2" />
            ) : (
              <Key className="w-5 h-5 mr-2" />
            )}
            Activer le code
          </Button>
        </div>

        <p className="text-xs text-gray-400 text-center mt-6">
          Vous n'avez pas de code ? Contactez un administrateur.
        </p>
      </div>
    </div>
  );
}