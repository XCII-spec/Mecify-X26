const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect, useCallback } from 'react';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Plus, MessageCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ConversationList from '@/components/messaging/ConversationList';
import ChatView from '@/components/messaging/ChatView';
import NewConversationModal from '@/components/messaging/NewConversationModal';
import { useMyPresence } from '@/hooks/usePresence';

export default function Messaging() {
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [showNewModal, setShowNewModal] = useState(false);
  const [showMobileChat, setShowMobileChat] = useState(false);
  const [aiConversation, setAiConversation] = useState(null);
  const queryClient = useQueryClient();

  // Fetch current user
  const { data: currentUser } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => db.auth.me()
  });

  // Track presence for current user
  useMyPresence(currentUser?.email);

  // Fetch all users
  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => db.entities.User.list()
  });

  // Fetch conversations
  const { data: conversations = [], isLoading: conversationsLoading } = useQuery({
    queryKey: ['conversations'],
    queryFn: () => db.entities.Conversation.list('-last_message_at'),
    refetchInterval: 3000 // Poll every 3 seconds
  });

  // Filter conversations for current user
  const myConversations = conversations.filter((conv) =>
  conv.participants?.includes(currentUser?.email)
  );

  // Create or get AI assistant conversation
  useEffect(() => {
    if (!currentUser || !conversations.length) return;

    const aiConv = conversations.find((c) =>
    c.participants?.includes('ai@messify.app') &&
    c.participants?.includes(currentUser.email)
    );

    if (aiConv) {
      setAiConversation(aiConv);
    } else {
      // Create AI conversation
      db.entities.Conversation.create({
        participants: [currentUser.email, 'ai@messify.app'],
        participant_names: [currentUser.full_name || currentUser.email, 'Assistant Messify'],
        last_message: 'Bonjour ! Je suis votre assistant personnel 👋',
        last_message_at: new Date().toISOString(),
        last_sender: 'ai@messify.app'
      }).then((conv) => {
        setAiConversation(conv);
        // Send welcome message
        db.entities.Message.create({
          conversation_id: conv.id,
          sender_email: 'ai@messify.app',
          sender_name: 'Assistant Messify',
          content: `Bonjour ${currentUser.full_name || 'cher utilisateur'} ! 👋\n\nJe suis votre assistant personnel sur Messify. Je suis là pour vous aider à découvrir la plateforme et répondre à vos questions.\n\nQue souhaitez-vous faire aujourd'hui ?`,
          read_by: [],
          status: 'delivered',
          is_ai_message: true
        });
        queryClient.invalidateQueries({ queryKey: ['conversations'] });
      });
    }
  }, [currentUser, conversations]);

  // Fetch messages for selected conversation
  const { data: messages = [], isLoading: messagesLoading } = useQuery({
    queryKey: ['messages', selectedConversation?.id],
    queryFn: () => db.entities.Message.filter(
      { conversation_id: selectedConversation?.id },
      'created_date'
    ),
    enabled: !!selectedConversation?.id,
    refetchInterval: 2000 // Poll every 2 seconds
  });

  // Create conversation mutation
  const createConversationMutation = useMutation({
    mutationFn: async (otherUser) => {
      // Check if conversation already exists
      const existingConv = myConversations.find((conv) =>
      conv.participants?.includes(otherUser.email) && conv.participants?.length === 2
      );

      if (existingConv) {
        return existingConv;
      }

      return db.entities.Conversation.create({
        participants: [currentUser.email, otherUser.email],
        participant_names: [currentUser.full_name || currentUser.email, otherUser.full_name || otherUser.email]
      });
    },
    onSuccess: (conversation) => {
      queryClient.invalidateQueries({ queryKey: ['conversations'] });
      setSelectedConversation(conversation);
      setShowNewModal(false);
      setShowMobileChat(true);
    }
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async ({ content, type = 'text', file_url, file_name, file_size, reply_to_content, reply_to_sender, reply_to_id } = {}) => {
      const msgData = {
        conversation_id: selectedConversation.id,
        sender_email: currentUser.email,
        sender_name: currentUser.full_name || currentUser.email,
        content,
        message_type: type,
        read_by: [currentUser.email],
        status: 'sent',
        ...(file_url && { file_url }),
        ...(file_name && { file_name }),
        ...(file_size && { file_size }),
        ...(reply_to_content && { reply_to_content }),
        ...(reply_to_sender && { reply_to_sender }),
        ...(reply_to_id && { reply_to_id }),
      };

      const message = await db.entities.Message.create(msgData);

      // Update conversation with last message
      await db.entities.Conversation.update(selectedConversation.id, {
        last_message: (content || file_name || '').substring(0, 100),
        last_message_at: new Date().toISOString(),
        last_sender: currentUser.email
      });

      // Check if this is AI conversation
      const isAIConv = selectedConversation.participants?.includes('ai@messify.app');

      if (isAIConv) {
        // Get AI response
        try {
          const aiResponse = await db.integrations.Core.InvokeLLM({
            prompt: `Tu es l'Assistant Messify, un guide amical intégré à la plateforme de messagerie et communautés Messify. L'utilisateur ${currentUser.full_name || 'un utilisateur'} te dit: "${content || '[fichier envoyé]'}". Réponds de manière naturelle, amicale et utile. Si l'utilisateur demande de l'aide, explique les fonctionnalités disponibles (messagerie, communautés, système de badges, notifications). Sois conversationnel et engage la discussion. Limite ta réponse à 2-3 phrases maximum pour rester naturel.`
          });

          await db.entities.Message.create({
            conversation_id: selectedConversation.id,
            sender_email: 'ai@messify.app',
            sender_name: 'Assistant Messify',
            content: aiResponse,
            read_by: [],
            status: 'delivered',
            is_ai_message: true
          });

          await db.entities.Conversation.update(selectedConversation.id, {
            last_message: aiResponse.substring(0, 100),
            last_message_at: new Date().toISOString(),
            last_sender: 'ai@messify.app'
          });
        } catch (error) {
          console.error('AI response error:', error);
        }
      } else {
        // Create notification for recipient
        const otherParticipant = selectedConversation.participants.find((p) => p !== currentUser.email);
        if (otherParticipant) {
          await db.entities.Notification.create({
            recipient_email: otherParticipant,
            sender_email: currentUser.email,
            sender_name: currentUser.full_name || currentUser.email,
            type: 'message',
            content: `vous a envoyé un message`,
            entity_id: selectedConversation.id,
            priority: 'normal'
          });
        }
      }

      // Mark as delivered after 500ms (simulate multi-device sync)
      setTimeout(() => {
        db.entities.Message.update(message.id, {
          ...message,
          status: 'delivered'
        }).catch(console.error);
      }, 500);

      return message;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['messages', selectedConversation?.id] });
      queryClient.invalidateQueries({ queryKey: ['conversations'] });
    }
  });

  const handleSelectConversation = (conv) => {
    setSelectedConversation(conv);
    setShowMobileChat(true);
  };

  const handleBack = () => {
    setShowMobileChat(false);
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-violet-50 to-purple-50">
        <Loader2 className="w-10 h-10 text-violet-500 animate-spin" />
      </div>);

  }

  return (
    <div className="h-screen flex bg-white dark:bg-gray-900 overflow-hidden">
      {/* Sidebar */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className={`w-full md:w-80 border-r border-gray-100 dark:border-gray-800 flex flex-col bg-white dark:bg-gray-900 ${showMobileChat ? 'hidden md:flex' : 'flex'}`}>

        {/* Header */}
        <div className="px-5 pt-5 pb-3 border-b border-gray-100 dark:border-gray-800">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">
              Messages
            </h1>
            <Button
              onClick={() => setShowNewModal(true)}
              size="icon"
              className="w-9 h-9 rounded-full bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700 shadow-md shadow-violet-500/30">
              <Plus className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Conversations List */}
        <div className="flex-1 overflow-y-auto flex flex-col">
          {conversationsLoading ?
            <div className="flex items-center justify-center py-16">
              <Loader2 className="w-8 h-8 text-violet-500 animate-spin" />
            </div> :
            <ConversationList
              conversations={myConversations}
              selectedId={selectedConversation?.id}
              onSelect={handleSelectConversation}
              currentUserEmail={currentUser?.email} />
          }
        </div>
      </motion.div>

      {/* Chat Area */}
      <div className={`flex-1 flex flex-col ${!showMobileChat ? 'hidden md:flex' : 'flex'}`}>
        <ChatView
          conversation={selectedConversation}
          messages={messages}
          currentUser={currentUser}
          onSendMessage={sendMessageMutation.mutateAsync}
          onBack={handleBack}
          isLoading={messagesLoading}
          isSending={sendMessageMutation.isPending} />
        
      </div>

      {/* New Conversation Modal */}
      <NewConversationModal
        open={showNewModal}
        onClose={() => setShowNewModal(false)}
        users={users}
        currentUserEmail={currentUser?.email}
        onSelectUser={createConversationMutation.mutateAsync}
        isCreating={createConversationMutation.isPending} />
      
    </div>);

}