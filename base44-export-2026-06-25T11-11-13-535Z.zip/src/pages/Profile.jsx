const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';

import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { LogOut, Loader2, Mail, MapPin, Globe, Phone, Edit, Moon, Sun, Crown, CheckCircle, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import BadgeDisplay, { getBadgeForFollowers } from '@/components/badges/BadgeDisplay';
import StatsCard from '@/components/profile/StatsCard';
import ReputationLevel from '@/components/profile/ReputationLevel';
import EditProfileModal from '@/components/profile/EditProfileModal';
import FriendsList from '@/components/friends/FriendsList';
import { useDarkMode } from '@/lib/DarkModeContext';

function SubscriptionStatus({ user }) {
  const isSubscribed = user?.is_subscribed;
  const expiresAt = user?.subscription_expires_at;
  const isExpired = expiresAt && new Date(expiresAt) < new Date();
  const active = isSubscribed && !isExpired;

  return (
    <div className={`flex items-center gap-3 p-4 rounded-xl mb-4 border ${active ? 'bg-yellow-50 border-yellow-200' : 'bg-gray-50 border-gray-200'}`}>
      <Crown className={`w-6 h-6 ${active ? 'text-yellow-500' : 'text-gray-400'}`} />
      <div className="flex-1">
        <div className="font-semibold text-gray-900 text-sm">
          {active ? 'Abonnement actif' : isSubscribed && isExpired ? 'Abonnement expiré' : 'Pas d\'abonnement'}
        </div>
        {expiresAt && (
          <div className="text-xs text-gray-500">
            {isExpired ? 'Expiré le ' : 'Expire le '}{new Date(expiresAt).toLocaleDateString('fr-FR')}
          </div>
        )}
        {!isSubscribed && (
          <div className="text-xs text-gray-500">Utilisez un code d'abonnement pour débloquer les fonctionnalités premium</div>
        )}
      </div>
      {active ? (
        <CheckCircle className="w-5 h-5 text-green-500" />
      ) : (
        <XCircle className="w-5 h-5 text-gray-400" />
      )}
    </div>
  );
}

function getInitials(name) {
  if (!name) return '?';
  return name.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2);
}

function getAvatarColor(email) {
  const colors = [
  'from-violet-500 to-purple-600',
  'from-blue-500 to-cyan-500',
  'from-emerald-500 to-teal-500',
  'from-orange-500 to-amber-500',
  'from-pink-500 to-rose-500'];

  const index = email ? email.charCodeAt(0) % colors.length : 0;
  return colors[index];
}

export default function Profile() {
  const [showEditModal, setShowEditModal] = useState(false);
  const [activeTab, setActiveTab] = useState('profile');
  const { isDark, toggle: toggleDark } = useDarkMode();

  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => db.auth.me()
  });

  const { data: userStats, isLoading: statsLoading } = useQuery({
    queryKey: ['userStats', user?.email],
    queryFn: async () => {
      const stats = await db.entities.UserStats.filter({ user_email: user.email });
      if (stats.length === 0) {
        // Create initial stats
        return db.entities.UserStats.create({
          user_email: user.email,
          follower_count: 0,
          following_count: 0,
          total_likes: 0,
          total_views: 0,
          total_posts: 0,
          reputation_level: 1,
          reputation_points: 0,
          badge: 'none',
          achievements: []
        });
      }
      return stats[0];
    },
    enabled: !!user
  });

  const { data: communities = [] } = useQuery({
    queryKey: ['userCommunities', user?.email],
    queryFn: () => db.entities.Community.filter({ creator_email: user.email }),
    enabled: !!user
  });

  const { data: posts = [] } = useQuery({
    queryKey: ['userPosts', user?.email],
    queryFn: () => db.entities.Post.filter({ author_email: user.email }, '-created_date'),
    enabled: !!user
  });

  if (userLoading || statsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-violet-500 animate-spin" />
      </div>);

  }

  const currentBadge = userStats?.badge || getBadgeForFollowers(userStats?.follower_count || 0);
  const profileTheme = user?.profile_theme || 'violet';
  const themeColors = {
    violet: 'from-violet-600 via-purple-600 to-pink-600',
    blue: 'from-blue-600 via-cyan-600 to-teal-600',
    green: 'from-emerald-600 via-teal-600 to-green-600',
    orange: 'from-orange-600 via-amber-600 to-yellow-600',
    pink: 'from-pink-600 via-rose-600 to-red-600',
    red: 'from-red-600 via-pink-600 to-purple-600'
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex justify-end gap-3 mb-8 flex-wrap">
          {/* Dark mode toggle */}
          <div className="flex items-center gap-2 px-3 py-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm">
            <Sun className="w-4 h-4 text-yellow-500" />
            <Switch checked={isDark} onCheckedChange={toggleDark} />
            <Moon className="w-4 h-4 text-violet-400" />
          </div>
          <Button
            onClick={() => setShowEditModal(true)}
            className="bg-gradient-to-r from-violet-600 to-purple-600 rounded-xl">
            <Edit className="w-5 h-5 mr-2" />
            Modifier
          </Button>
          <Button
            variant="outline"
            onClick={() => db.auth.logout()}
            className="rounded-xl text-red-600 hover:text-red-700 hover:bg-red-50">
            <LogOut className="w-5 h-5 mr-2" />
            Déconnexion
          </Button>
        </div>

        {/* Profile Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden mb-8">
          
          {/* Cover */}
          <div className={`h-32 bg-gradient-to-r ${themeColors[profileTheme]} relative`}>
            {user?.cover_url &&
            <img src={user.cover_url} alt="Cover" className="w-full h-full object-cover" />
            }
          </div>

          <div className="px-8 pb-8 bg-[#ccc9c7]">
            {/* Avatar */}
            <div className="flex items-end justify-between -mt-16 mb-6">
              <div className="relative">
                {user?.avatar_url ?
                <img
                  src={user.avatar_url}
                  alt={user.full_name}
                  className="w-32 h-32 rounded-3xl object-cover shadow-2xl ring-4 ring-white" /> :

                <div className={`w-32 h-32 rounded-3xl bg-gradient-to-br ${getAvatarColor(user?.email)} flex items-center justify-center text-white text-4xl font-bold shadow-2xl ring-4 ring-white`}>
                    {getInitials(user?.full_name)}
                  </div>
                }
                {currentBadge && currentBadge !== 'none' &&
                <div className="absolute -bottom-2 -right-2">
                    <BadgeDisplay badge={currentBadge} size="xl" animated />
                  </div>
                }
              </div>
            </div>

            {/* User Info */}
            <div className="mb-6">
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-3xl font-bold text-gray-900">
                  {user?.full_name || 'Utilisateur'}
                </h1>
                {currentBadge && currentBadge !== 'none' &&
                <BadgeDisplay badge={currentBadge} size="md" showLabel />
                }
              </div>
              <div className="flex items-center gap-2 text-gray-600 mb-2">
                <Mail className="w-4 h-4" />
                <span>{user?.email}</span>
              </div>
              {(user?.status || user?.status_emoji) &&
              <div className="flex items-center gap-2 mt-2 px-3 py-1.5 bg-gray-50 rounded-full inline-flex">
                  {user.status_emoji && <span className="text-lg">{user.status_emoji}</span>}
                  {user.status && <span className="text-sm text-gray-700">{user.status}</span>}
                </div>
              }
              {user?.bio &&
              <p className="text-gray-700 mt-3 max-w-2xl">{user.bio}</p>
              }
              <div className="flex flex-wrap items-center gap-4 mt-3 text-sm text-gray-600">
                {user?.location &&
                <div className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    {user.location}
                  </div>
                }
                {user?.website &&
                <a href={user.website} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 hover:text-violet-600">
                    <Globe className="w-4 h-4" />
                    {user.website}
                  </a>
                }
                {user?.phone &&
                <div className="flex items-center gap-1">
                    <Phone className="w-4 h-4" />
                    {user.phone}
                  </div>
                }
              </div>
              {user?.interests && user.interests.length > 0 &&
              <div className="flex flex-wrap gap-2 mt-3">
                  {user.interests.map((interest, i) =>
                <span key={i} className="px-3 py-1 bg-violet-50 text-violet-700 rounded-full text-sm font-medium">
                      {interest}
                    </span>
                )}
                </div>
              }
              
              {/* Social Links */}
              {user?.social_links && Object.values(user.social_links).some((link) => link) &&
              <div className="flex flex-wrap gap-2 mt-4">
                  {user.social_links.twitter &&
                <a
                  href={`https://twitter.com/${user.social_links.twitter.replace('@', '')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-black text-white flex items-center justify-center hover:scale-110 transition-transform">
                  
                      𝕏
                    </a>
                }
                  {user.social_links.linkedin &&
                <a
                  href={user.social_links.linkedin.startsWith('http') ? user.social_links.linkedin : `https://${user.social_links.linkedin}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center hover:scale-110 transition-transform text-xs font-bold">
                  
                      in
                    </a>
                }
                  {user.social_links.github &&
                <a
                  href={user.social_links.github.startsWith('http') ? user.social_links.github : `https://${user.social_links.github}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-gray-800 text-white flex items-center justify-center hover:scale-110 transition-transform">
                  
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z" /></svg>
                    </a>
                }
                  {user.social_links.instagram &&
                <a
                  href={`https://instagram.com/${user.social_links.instagram.replace('@', '')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-600 via-pink-600 to-orange-500 text-white flex items-center justify-center hover:scale-110 transition-transform">
                  
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" /></svg>
                    </a>
                }
                  {user.social_links.facebook &&
                <a
                  href={user.social_links.facebook.startsWith('http') ? user.social_links.facebook : `https://${user.social_links.facebook}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center hover:scale-110 transition-transform">
                  
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" /></svg>
                    </a>
                }
                  {user.social_links.youtube &&
                <a
                  href={user.social_links.youtube.startsWith('http') ? user.social_links.youtube : `https://${user.social_links.youtube}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-red-600 text-white flex items-center justify-center hover:scale-110 transition-transform">
                  
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" /></svg>
                    </a>
                }
                </div>
              }
            </div>

            {/* Quick Stats */}
            <div className="flex gap-8 text-center mb-6 pb-6 border-b border-gray-100">
              <div>
                <div className="text-2xl font-bold text-gray-900">{communities.length}</div>
                <div className="text-sm text-gray-500">Communautés créées</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">{posts.length}</div>
                <div className="text-sm text-gray-500">Posts publiés</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">{userStats?.achievements?.length || 0}</div>
                <div className="text-sm text-gray-500">Succès débloqués</div>
              </div>
            </div>

            {/* Subscription Status */}
            <SubscriptionStatus user={user} />
          </div>
        </motion.div>

        {/* Tabs */}
        <div className="flex gap-2 mb-8 bg-white rounded-2xl p-2 shadow-md">
          <button
            onClick={() => setActiveTab('profile')}
            className={`flex-1 px-6 py-3 rounded-xl font-medium transition-colors ${
            activeTab === 'profile' ?
            'bg-gradient-to-r from-violet-600 to-purple-600 text-white' :
            'text-gray-600 hover:bg-gray-50'}`
            }>
            
            Profil
          </button>
          <button
            onClick={() => setActiveTab('friends')}
            className={`flex-1 px-6 py-3 rounded-xl font-medium transition-colors ${
            activeTab === 'friends' ?
            'bg-gradient-to-r from-violet-600 to-purple-600 text-white' :
            'text-gray-600 hover:bg-gray-50'}`
            }>
            
            Contacts
          </button>
        </div>

        {activeTab === 'friends' ?
        <FriendsList userEmail={user?.email} /> :

        <>
            {/* Stats Cards */}
            <div className="mb-8">
              <StatsCard stats={userStats} />
            </div>

        {/* Reputation */}
        <ReputationLevel
            level={userStats?.reputation_level || 1}
            points={userStats?.reputation_points || 0} />
          

        {/* Achievements */}
        {userStats?.achievements && userStats.achievements.length > 0 &&
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white rounded-2xl shadow-lg border border-gray-100 p-8 mt-8">
            
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Succès débloqués</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {userStats.achievements.map((achievement, index) =>
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                className="bg-gradient-to-br from-violet-50 to-purple-50 rounded-xl p-4 border border-violet-200">
                
                  <div className="text-3xl mb-2">🏆</div>
                  <div className="font-semibold text-gray-900">{achievement}</div>
                </motion.div>
              )}
            </div>
          </motion.div>
          }
          </>
        }

        {/* Edit Profile Modal */}
        <EditProfileModal
          open={showEditModal}
          onClose={() => setShowEditModal(false)}
          user={user} />
        
      </div>
    </div>);

}