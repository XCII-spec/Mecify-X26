const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Palette, Save, Upload, Loader2, Eye, Key, BarChart2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import SubscriptionCodesManager from '@/components/admin/SubscriptionCodesManager';
import GlobalStats from '@/components/admin/GlobalStats';

const THEMES = {
  default: {
    name: 'Par défaut',
    heroTitle: 'Connectez-vous avec ceux qui comptent',
    heroSubtitle: 'Nouvelle expérience de messagerie',
    heroDescription: 'Une plateforme de messagerie moderne, rapide et intuitive pour rester en contact avec vos proches',
    bgColor: 'from-violet-50 via-purple-50 to-pink-50',
    primaryColor: 'from-violet-600 to-purple-600',
  },
  christmas: {
    name: '🎄 Noël',
    heroTitle: 'Partagez la magie de Noël',
    heroSubtitle: 'Joyeuses fêtes de fin d\'année',
    heroDescription: 'Restez connecté avec vos proches pendant les fêtes et partagez des moments magiques',
    bgColor: 'from-red-50 via-green-50 to-red-50',
    primaryColor: 'from-red-600 to-green-600',
  },
  newyear: {
    name: '🎉 Nouvel An',
    heroTitle: 'Nouvelle année, nouvelles connexions',
    heroSubtitle: 'Bonne année 2026',
    heroDescription: 'Commencez l\'année en beauté en restant connecté avec ceux qui comptent',
    bgColor: 'from-yellow-50 via-orange-50 to-yellow-50',
    primaryColor: 'from-yellow-600 to-orange-600',
  },
  valentine: {
    name: '❤️ Saint-Valentin',
    heroTitle: 'Partagez l\'amour',
    heroSubtitle: 'Joyeuse Saint-Valentin',
    heroDescription: 'Restez connecté avec vos êtres chers et partagez des messages d\'amour',
    bgColor: 'from-pink-50 via-rose-50 to-pink-50',
    primaryColor: 'from-pink-600 to-rose-600',
  },
  halloween: {
    name: '🎃 Halloween',
    heroTitle: 'Partagez des frissons',
    heroSubtitle: 'Joyeux Halloween',
    heroDescription: 'Restez connecté avec vos amis pour une soirée effrayante',
    bgColor: 'from-orange-50 via-gray-50 to-orange-50',
    primaryColor: 'from-orange-600 to-gray-600',
  },
  summer: {
    name: '☀️ Été',
    heroTitle: 'Profitez de l\'été',
    heroSubtitle: 'Bonnes vacances',
    heroDescription: 'Partagez vos aventures estivales avec vos proches',
    bgColor: 'from-cyan-50 via-blue-50 to-cyan-50',
    primaryColor: 'from-cyan-600 to-blue-600',
  },
};

export default function Admin() {
  const [uploading, setUploading] = useState(false);
  const [activeTab, setActiveTab] = useState('theme');
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => db.auth.me(),
  });

  const { data: configs = [] } = useQuery({
    queryKey: ['homeConfigs'],
    queryFn: () => db.entities.HomeConfig.list(),
  });

  const activeConfig = configs.find(c => c.is_active) || {};
  const selectedTheme = THEMES[activeConfig.theme] || THEMES.default;

  const [formData, setFormData] = useState({
    theme: activeConfig.theme || 'default',
    hero_title: activeConfig.hero_title || '',
    hero_subtitle: activeConfig.hero_subtitle || '',
    hero_description: activeConfig.hero_description || '',
    hero_image: activeConfig.hero_image || '',
    background_color: activeConfig.background_color || '',
    primary_color: activeConfig.primary_color || '',
    features_visible: activeConfig.features_visible !== false,
    custom_message: activeConfig.custom_message || '',
  });

  const saveConfigMutation = useMutation({
    mutationFn: async (data) => {
      // Désactiver toutes les configs
      for (const config of configs) {
        if (config.is_active) {
          await db.entities.HomeConfig.update(config.id, { ...config, is_active: false });
        }
      }

      // Créer ou mettre à jour la config active
      if (activeConfig.id) {
        return await db.entities.HomeConfig.update(activeConfig.id, {
          ...data,
          is_active: true,
        });
      } else {
        return await db.entities.HomeConfig.create({
          ...data,
          is_active: true,
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['homeConfigs'] });
      toast.success('Configuration sauvegardée');
    },
  });

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    try {
      const { file_url } = await db.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, hero_image: file_url });
      toast.success('Image uploadée');
    } catch (error) {
      toast.error('Erreur lors de l\'upload');
    } finally {
      setUploading(false);
    }
  };

  const applyTheme = (themeKey) => {
    const theme = THEMES[themeKey];
    setFormData({
      ...formData,
      theme: themeKey,
      hero_title: theme.heroTitle,
      hero_subtitle: theme.heroSubtitle,
      hero_description: theme.heroDescription,
      background_color: theme.bgColor,
      primary_color: theme.primaryColor,
    });
  };

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100">
        <div className="text-center">
          <p className="text-gray-500 mb-4">Accès réservé aux administrateurs</p>
          <Button onClick={() => db.auth.redirectToLogin()}>Se connecter</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Administration</h1>
            <p className="text-gray-600 mt-1">Gérez la plateforme</p>
          </div>
          {activeTab === 'theme' && (
            <Button
              onClick={() => saveConfigMutation.mutate(formData)}
              disabled={saveConfigMutation.isPending}
              className="bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700"
            >
              {saveConfigMutation.isPending ? (
                <Loader2 className="w-5 h-5 animate-spin mr-2" />
              ) : (
                <Save className="w-5 h-5 mr-2" />
              )}
              Sauvegarder
            </Button>
          )}
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-8 border-b border-gray-200">
          <button
            onClick={() => setActiveTab('theme')}
            className={`flex items-center gap-2 px-4 py-2 text-sm font-medium border-b-2 transition-colors ${activeTab === 'theme' ? 'border-violet-600 text-violet-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
          >
            <Palette className="w-4 h-4" />
            Thème & Page d'accueil
          </button>
          <button
            onClick={() => setActiveTab('codes')}
            className={`flex items-center gap-2 px-4 py-2 text-sm font-medium border-b-2 transition-colors ${activeTab === 'codes' ? 'border-violet-600 text-violet-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
          >
            <Key className="w-4 h-4" />
            Codes d'abonnement
          </button>
          <button
            onClick={() => setActiveTab('stats')}
            className={`flex items-center gap-2 px-4 py-2 text-sm font-medium border-b-2 transition-colors ${activeTab === 'stats' ? 'border-violet-600 text-violet-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
          >
            <BarChart2 className="w-4 h-4" />
            Statistiques
          </button>
        </div>

        {activeTab === 'codes' && <SubscriptionCodesManager />}
        {activeTab === 'stats' && <GlobalStats />}

        {activeTab === 'theme' && <div className="grid lg:grid-cols-2 gap-8">
          {/* Form */}
          <div className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-2xl shadow-md border border-gray-100 p-6"
            >
              <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                <Palette className="w-5 h-5" />
                Configuration du thème
              </h2>

              <div className="space-y-4">
                <div>
                  <Label>Thème prédéfini</Label>
                  <Select value={formData.theme} onValueChange={applyTheme}>
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(THEMES).map(([key, theme]) => (
                        <SelectItem key={key} value={key}>
                          {theme.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Titre principal</Label>
                  <Input
                    value={formData.hero_title}
                    onChange={(e) => setFormData({ ...formData, hero_title: e.target.value })}
                    placeholder="Connectez-vous avec ceux qui comptent"
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Sous-titre</Label>
                  <Input
                    value={formData.hero_subtitle}
                    onChange={(e) => setFormData({ ...formData, hero_subtitle: e.target.value })}
                    placeholder="Nouvelle expérience de messagerie"
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Description</Label>
                  <Textarea
                    value={formData.hero_description}
                    onChange={(e) => setFormData({ ...formData, hero_description: e.target.value })}
                    placeholder="Une plateforme de messagerie moderne..."
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Image hero (optionnelle)</Label>
                  <div className="mt-2 flex gap-2">
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      disabled={uploading}
                      className="flex-1"
                    />
                    {uploading && <Loader2 className="w-5 h-5 animate-spin" />}
                  </div>
                  {formData.hero_image && (
                    <img
                      src={formData.hero_image}
                      alt="Hero"
                      className="mt-2 rounded-lg w-full h-32 object-cover"
                    />
                  )}
                </div>

                <div>
                  <Label>Message personnalisé (optionnel)</Label>
                  <Textarea
                    value={formData.custom_message}
                    onChange={(e) => setFormData({ ...formData, custom_message: e.target.value })}
                    placeholder="Message spécial pour les visiteurs..."
                    className="mt-2"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>Afficher les fonctionnalités</Label>
                  <Switch
                    checked={formData.features_visible}
                    onCheckedChange={(checked) => setFormData({ ...formData, features_visible: checked })}
                  />
                </div>
              </div>
            </motion.div>
          </div>

          {/* Preview */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-2xl shadow-md border border-gray-100 p-6 sticky top-8"
            >
              <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                <Eye className="w-5 h-5" />
                Aperçu
              </h2>

              <div className={`rounded-xl overflow-hidden border-2 border-gray-200 bg-gradient-to-br ${formData.background_color || selectedTheme.bgColor}`}>
                <div className="p-8 text-center">
                  <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/80 backdrop-blur-sm border border-violet-200 shadow-lg mb-4`}>
                    <span className="text-xs font-medium text-violet-900">
                      {formData.hero_subtitle || selectedTheme.heroSubtitle}
                    </span>
                  </div>
                  <h1 className="text-2xl font-bold text-gray-900 mb-2">
                    {formData.hero_title || selectedTheme.heroTitle}
                  </h1>
                  <p className="text-sm text-gray-600 mb-4">
                    {formData.hero_description || selectedTheme.heroDescription}
                  </p>
                  {formData.custom_message && (
                    <div className="mt-4 p-3 bg-white/50 rounded-lg border border-violet-200">
                      <p className="text-sm text-violet-900 font-medium">{formData.custom_message}</p>
                    </div>
                  )}
                  {formData.hero_image && (
                    <img
                      src={formData.hero_image}
                      alt="Hero preview"
                      className="mt-4 rounded-lg w-full h-24 object-cover"
                    />
                  )}
                  <button className={`mt-4 px-6 py-2 rounded-full bg-gradient-to-r ${formData.primary_color || selectedTheme.primaryColor} text-white text-sm font-medium`}>
                    Commencer
                  </button>
                </div>
              </div>

              <p className="text-xs text-gray-500 mt-4 text-center">
                Ceci est un aperçu simplifié. Visitez la page d'accueil pour voir le résultat complet.
              </p>
            </motion.div>
          </div>
        </div>}
      </div>
    </div>
  );
}