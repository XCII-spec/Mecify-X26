import React, { useState, useEffect } from 'react';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { ArrowLeft, Users, UserPlus, UserCheck, Image, Link as LinkIcon, Loader2, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import PostCard from '@/components/community/PostCard';
import CommentSection from '@/components/community/CommentSection';
import BadgeDisplay, { getBadgeForFollowers } from '@/components/badges/BadgeDisplay';

export default function CommunityDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const communityId = urlParams.get('id');
  
  const [newPostContent, setNewPostContent] = useState('');
  const [selectedPost, setSelectedPost] = useState(null);
  const [linkUrl, setLinkUrl] = useState('');
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],