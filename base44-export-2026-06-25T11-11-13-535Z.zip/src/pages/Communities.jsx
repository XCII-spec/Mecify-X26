const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Plus, Users, Search, TrendingUp, Loader2, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import BadgeDisplay from '@/components/badges/BadgeDisplay';
import CommunityFilters from '@/components/communities/CommunityFilters';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

export default function Communities() {
  const [search, setSearch] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newCommunity, setNewCommunity] = useState({ name: '', description: '', type: 'public' });
  const [filters, setFilters] = useState({ type: 'all', size: 'all', sort: 'popular' });
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => db.auth.me(),
  });

  const { data: communities = [], isLoading } = useQuery({
    queryKey: ['communities'],
    queryFn: () => db.entities.Community.list('-follower_count'),
  });

  const { data: userStats = [] } = useQuery({
    queryKey: ['allUserStats'],
    queryFn: () => db.entities.UserStats.list(),
  });

  const { data: follows = [] } = useQuery({
    queryKey: ['userFollows', user?.email],
    queryFn: () => db.entities.Follow.filter({ follower_email: user?.email }),
    enabled: !!user,
  });

  const createCommunityMutation = useMutation({
    mutationFn: async (data) => {
      const community = await db.entities.Community.create({
        ...data,
        creator_email: user.email,
        creator_name: user.full_name || user.email,
        members: [user.email],
        admins: [user.email],
        moderators: [],
        follower_count: 0,
        post_count: 0,
      });

      // Create or update user stats
      const existingStats = userStats.find(s => s.user_email === user.email);
      if (existingStats) {
        await db.entities.UserStats.update(existingStats.id, {
          ...existingStats,
          total_posts: (existingStats.total_posts || 0),
        });
      } else {
        await db.entities.UserStats.create({
          user_email: user.email,
          follower_count: 0,
          total_posts: 0,
          total_likes: 0,
          total_views: 0,
          reputation_points: 0,
          reputation_level: 1,
        });
      }

      return community;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['communities'] });
      setShowCreateModal(false);
      setNewCommunity({ name: '', description: '', type: 'public' });
    },
  });

  // Apply filters
  let filteredCommunities = communities.filter(c =>
    c.name?.toLowerCase().includes(search.toLowerCase()) ||
    c.description?.toLowerCase().includes(search.toLowerCase())
  );

  // Filter by type
  if (filters.type !== 'all') {
    filteredCommunities = filteredCommunities.filter(c => c.type === filters.type);
  }

  // Filter by size
  if (filters.size !== 'all') {
    filteredCommunities = filteredCommunities.filter(c => {
      const count = c.follower_count || 0;
      if (filters.size === 'small') return count < 100;
      if (filters.size === 'medium') return count >= 100 && count < 1000;
      if (filters.size === 'large') return count >= 1000;
      return true;
    });
  }

  // Sort
  filteredCommunities = [...filteredCommunities].sort((a, b) => {
    if (filters.sort === 'popular') return (b.follower_count || 0) - (a.follower_count || 0);
    if (filters.sort === 'recent') return new Date(b.created_date) - new Date(a.created_date);
    if (filters.sort === 'active') return (b.post_count || 0) - (a.post_count || 0);
    return 0;
  });

  // Recommendations
  const myFollowedCommunities = follows.filter(f => f.following_type === 'community').map(f => f.entity_id);
  const recommendedCommunities = communities
    .filter(c => !myFollowedCommunities.includes(c.id))
    .filter(c => {
      // Recommend based on common members
      const commonMembers = c.members?.filter(m => 
        communities.some(mc => myFollowedCommunities.includes(mc.id) && mc.members?.includes(m))
      ) || [];
      return (c.follower_count || 0) > 50 || commonMembers.length > 0;
    })
    .sort((a, b) => (b.follower_count || 0) - (a.follower_count || 0))
    .slice(0, 3);

  const getUserBadge = (email) => {
    const stats = userStats.find(s => s.user_email === email);
    return stats?.badge || 'none';
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-violet-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Communautés</h1>
            <p className="text-gray-600 mt-1">Découvrez et rejoignez des communautés</p>
          </div>
          <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700 shadow-lg">
                <Plus className="w-5 h-5 mr-2" />
                Créer une communauté
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Créer une communauté</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div>
                  <Label>Nom</Label>
                  <Input
                    value={newCommunity.name}
                    onChange={(e) => setNewCommunity({ ...newCommunity, name: e.target.value })}
                    placeholder="Nom de la communauté"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label>Description</Label>
                  <Textarea
                    value={newCommunity.description}
                    onChange={(e) => setNewCommunity({ ...newCommunity, description: e.target.value })}
                    placeholder="Décrivez votre communauté..."
                    className="mt-1"
                  />
                </div>
                <Button
                  onClick={() => createCommunityMutation.mutate(newCommunity)}
                  disabled={!newCommunity.name || createCommunityMutation.isPending}
                  className="w-full bg-gradient-to-r from-violet-600 to-purple-600"
                >
                  {createCommunityMutation.isPending ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    'Créer'
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher une communauté..."
            className="pl-12 h-12 rounded-xl bg-white shadow-sm"
          />
        </div>

        {/* Filters */}
        <CommunityFilters filters={filters} onFilterChange={setFilters} />

        {/* Recommendations */}
        {recommendedCommunities.length > 0 && !search && (
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-5 h-5 text-violet-600" />
              <h2 className="text-xl font-bold text-gray-900">Recommandations pour vous</h2>
            </div>
            <div className="grid sm:grid-cols-3 gap-4">
              {recommendedCommunities.map((community) => {
                const creatorBadge = getUserBadge(community.creator_email);
                return (
                  <Link key={community.id} to={createPageUrl(`CommunityDetail?id=${community.id}`)}>
                    <div className="bg-gradient-to-br from-violet-50 to-purple-50 rounded-xl p-4 border-2 border-violet-200 hover:border-violet-300 transition-all hover:shadow-lg">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-bold text-gray-900 flex-1 line-clamp-1">{community.name}</h3>
                        {creatorBadge && creatorBadge !== 'none' && (
                          <BadgeDisplay badge={creatorBadge} size="xs" />
                        )}
                      </div>
                      <p className="text-sm text-gray-600 line-clamp-2 mb-3">{community.description}</p>
                      <div className="flex items-center gap-3 text-xs text-gray-500">
                        <div className="flex items-center gap-1">
                          <Users className="w-3 h-3" />
                          {community.follower_count || 0}
                        </div>
                        <div className="flex items-center gap-1">
                          <TrendingUp className="w-3 h-3" />
                          {community.post_count || 0} posts
                        </div>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        )}

        {/* Communities Grid */}
        {isLoading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-10 h-10 text-violet-500 animate-spin" />
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCommunities.map((community, index) => {
              const creatorBadge = getUserBadge(community.creator_email);
              return (
                <motion.div
                  key={community.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Link to={createPageUrl(`CommunityDetail?id=${community.id}`)}>
                    <div className="bg-white rounded-2xl shadow-md border border-gray-100 overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1 h-full">
                      {community.image_url && (
                        <div className="h-40 overflow-hidden">
                          <img
                            src={community.image_url}
                            alt={community.name}
                            className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                          />
                        </div>
                      )}
                      <div className="p-6">
                        <div className="flex items-start justify-between mb-3">
                          <h3 className="text-xl font-bold text-gray-900 line-clamp-1">
                            {community.name}
                          </h3>
                          {creatorBadge && creatorBadge !== 'none' && (
                            <BadgeDisplay badge={creatorBadge} size="sm" />
                          )}
                        </div>
                        <p className="text-gray-600 text-sm line-clamp-2 mb-4">
                          {community.description || 'Aucune description'}
                        </p>
                        <div className="flex items-center justify-between text-sm">
                          <div className="flex items-center gap-1 text-gray-500">
                            <Users className="w-4 h-4" />
                            <span>{community.follower_count || 0} membres</span>
                          </div>
                          <div className="flex items-center gap-1 text-gray-500">
                            <TrendingUp className="w-4 h-4" />
                            <span>{community.post_count || 0} posts</span>
                          </div>
                        </div>
                        <div className="mt-4 pt-4 border-t border-gray-100">
                          <div className="text-xs text-gray-500">
                            Créé par <span className="font-medium text-gray-700">{community.creator_name}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        )}

        {filteredCommunities.length === 0 && !isLoading && (
          <div className="text-center py-16">
            <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">Aucune communauté trouvée</p>
          </div>
        )}
      </div>
    </div>
  );
}